import { Injectable } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

@Injectable()
export class MonitoringAccessGuard extends AuthGuard('jwt-monitoring-access') {
  constructor() {
    super();
  }
}
